Cracked Dlls of Bunifu C# Framework - WinForms (NuGet Version: 5.0.7)

How to use?

Create a folder where u want to store the DLLs.
Open Visual Studio IDE and right click on the toolbox, and click 'Choose Items'
When its done loading click browse, And select all the bunifu DLLs
Use Bunifu for free!
!!!! Sometimes u get an error related to the licensing when running compiler. To fix this remove the license file from the project. !!!!
